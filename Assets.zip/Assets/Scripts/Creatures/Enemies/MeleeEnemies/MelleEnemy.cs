using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor.Experimental.GraphView;
using UnityEngine;
using UnityEngine.AI;

public class MelleEnemy : Enemy
{
    [SerializeField] private string playerTag;

    protected GameObject player;
    private NavMeshAgent agent;

    protected void Awake()
    {
        base.Awake();
        player = GameObject.FindGameObjectWithTag(playerTag);
        agent = GetComponent<NavMeshAgent>();
        agent.updateRotation = false;
        agent.updateUpAxis = false;
        agent.speed = speed;
    }

    private void Update()
    {
        FollowPlayer();
        LookAtThePlayer();
    }

    protected void FollowPlayer()
    {
        var path = agent.path;
        agent.CalculatePath(player.transform.position, path);
        agent.path = path;
        var direction = agent.nextPosition - transform.position;
        Movement(direction);
    }

    protected void LookAtThePlayer()
    {
        var angle = Mathf.Atan2(agent.nextPosition.y, agent.nextPosition.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle));
    }
}
